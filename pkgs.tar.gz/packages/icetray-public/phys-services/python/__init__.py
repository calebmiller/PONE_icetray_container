from icecube import icetray
from icecube._phys_services import *

del icetray
