
#include "PROPOSAL/PropagatorService.h"
#include "PROPOSAL/Propagator.h"
#include "PROPOSAL/Logging.h"

using namespace PROPOSAL;

// ------------------------------------------------------------------------- //
PropagatorService::PropagatorService()
    : propagator_map_()
{
}

// ------------------------------------------------------------------------- //
PropagatorService::~PropagatorService()
{
    for (PropagatorMap::const_iterator it = propagator_map_.begin(); it != propagator_map_.end(); ++it)
    {
        delete it->second;
    }

    propagator_map_.clear();
}

// ------------------------------------------------------------------------- //
void PropagatorService::RegisterPropagator(const Propagator& propagator)
{
    ParticleDef particle_def = const_cast<Propagator&>(propagator).GetParticle().GetParticleDef();
    if (propagator_map_.find(particle_def) != propagator_map_.end())
    {
        log_warn("Propagator for particle %s is already registered!", particle_def.name.c_str());
    } else
    {
        propagator_map_[particle_def] = new Propagator(propagator);
    }
}

// ------------------------------------------------------------------------- //
bool PropagatorService::IsRegistered(const ParticleDef& particle_def)
{
    return propagator_map_.find(particle_def) != propagator_map_.end();
}

// ------------------------------------------------------------------------- //
std::vector<DynamicData*> PropagatorService::Propagate(Particle& particle, double distance)
{
    ParticleDef particle_def = particle.GetParticleDef();

    PropagatorMap::iterator it = propagator_map_.find(particle_def);

    if (it != propagator_map_.end())
    {
        Propagator* propagator = it->second;

        Particle& prop_particle = propagator->GetParticle();
        prop_particle.InjectState(particle);

        std::vector<DynamicData*> secondaries = propagator->Propagate(distance);

        particle.InjectState(prop_particle);

        return secondaries;
    } else
    {
        log_warn("Propagator for particle %s not found! Empty secondary vector will be returned!",
                 particle_def.name.c_str());
        return std::vector<DynamicData*>();
    }
}

Propagator* PropagatorService::GetPropagatorToParticleDef(const ParticleDef& particle_def)
{
    PropagatorMap::iterator it = propagator_map_.find(particle_def);
    if (it != propagator_map_.end())
    {
        return it->second;
    }
    else
    {
        log_warn("Propagator for particle %s not found! Default nullptr will be returned!",
                 particle_def.name.c_str());
        Propagator* default_propagator = nullptr;
        return default_propagator;
    }
}
