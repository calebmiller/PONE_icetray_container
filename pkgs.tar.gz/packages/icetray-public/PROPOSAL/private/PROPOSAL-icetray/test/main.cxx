#include <I3TestMain.ixx>
#include <I3Test.h>

#include <PROPOSAL-icetray/I3PropagatorServicePROPOSAL.h>
#include <PROPOSAL-icetray/SimplePropagator.h>
#include <dataclasses/physics/I3Particle.h>
#include <phys-services/I3SPRNGRandomService.h>

#include <boost/make_shared.hpp>

TEST_GROUP(PROPOSAL);

static I3Particle make_particle(double z_position)
{
    I3Particle p;
    p.SetPos(0, 0, z_position);
    p.SetDir(0, 0, -1);
    p.SetTime(0);
    p.SetType(I3Particle::MuMinus);
    p.SetLocationType(I3Particle::InIce);
    p.SetEnergy(1e6);

    return p;
}

TEST(MMCTrackBug)
{
    PROPOSAL::RandomGenerator::Get().SetSeed(0);

    // propagate for 2 km
    auto prop = std::make_shared<PROPOSAL::I3PropagatorServicePROPOSAL>(
        "", true, I3Particle::unknown, 2000 / I3Units::cm);

    I3PropagatorService::DiagnosticMapPtr frame(new I3PropagatorService::DiagnosticMap);
    I3FramePtr dummy(new I3Frame()); 

    // propagate particle that will reach the detector
    I3Particle p_near              = make_particle(1000); 
    prop->Propagate(p_near, frame, dummy);

    // propagate particle that won't reach the detector
    I3Particle p_far              = make_particle(10000);
    prop->Propagate(p_far, frame, dummy);

    // since only the first particle reaches the detector, only one particle
    // should be written on the MMCTrack
    ENSURE_EQUAL(frame->Get<I3MMCTrackListPtr>("MMCTrackList")->size(), 1u);

}