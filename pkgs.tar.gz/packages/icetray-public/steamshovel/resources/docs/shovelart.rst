.. _shovelart-ref:

shovelart Reference (Python module)
===================================

Reference documentation automatically generated from docstrings.

.. automodule:: icecube.shovelart
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:
       

