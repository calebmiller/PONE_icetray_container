#!/usr/bin/env python3

if __name__ == '__main__':
    print('i3digger.py has moved to dataio-pyshovel')
    # file is located at dataio/resources/dataio-pyshovel.py
