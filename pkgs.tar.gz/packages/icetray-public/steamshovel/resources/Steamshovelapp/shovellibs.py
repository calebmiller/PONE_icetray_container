import sys
for x in sys.path:
	print( 'python:'+x )

app.quit()