#include "TimeSpinBox.h"
#include "moc_TimeSpinBox.cpp"

// needed by auto-moc
