#ifndef I3_SHOVEL_SHELLWIDGET_H
#define I3_SHOVEL_SHELLWIDGET_H

#include <QWidget>
class QKeyEvent;

class ShellWidget : public QWidget
{
public:
	ShellWidget( QWidget* parent = NULL );
};

#endif /* I3_SHOVEL_SHELLWIDGET_H */
