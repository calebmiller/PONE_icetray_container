#include "BindSignal.h"
#include "moc_BindSignal.cpp"

/* This file just exists to keep moc happy */
