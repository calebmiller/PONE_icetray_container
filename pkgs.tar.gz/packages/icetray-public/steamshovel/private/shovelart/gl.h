#ifndef I3_SHOVEL_GL_H_INCLUDED
#define I3_SHOVEL_GL_H_INCLUDED

#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include <GL/gl.h>
#include <GL/glu.h>
#endif

#endif /* I3_SHOVEL_GL_H_INCLUDED */

